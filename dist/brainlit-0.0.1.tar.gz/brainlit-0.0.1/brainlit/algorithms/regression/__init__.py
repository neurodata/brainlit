from brainlit.algorithms.regression.log_regression import *
from brainlit.algorithms.regression.log_regression_segment import *
